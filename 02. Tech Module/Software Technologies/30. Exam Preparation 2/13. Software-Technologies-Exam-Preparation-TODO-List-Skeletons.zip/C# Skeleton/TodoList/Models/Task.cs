﻿using System.ComponentModel.DataAnnotations;

namespace TodoList.Models
{
    public class Task
    {
        //TODO: Implement me...
    }
}