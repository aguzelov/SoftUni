﻿using System.ComponentModel.DataAnnotations;

namespace TeisterMask.Models
{
    public class Task
    {
	    // TODO: Implement me...
    }
}