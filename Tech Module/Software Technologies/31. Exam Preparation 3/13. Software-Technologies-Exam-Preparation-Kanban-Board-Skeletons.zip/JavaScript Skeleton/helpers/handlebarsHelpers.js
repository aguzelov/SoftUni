const Handlebars = require('hbs');
Handlebars.registerHelper("checkif", require('handlebars-helper-checkif'));