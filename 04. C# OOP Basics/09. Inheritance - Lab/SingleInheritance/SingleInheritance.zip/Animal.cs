﻿public class Animal
{
    public Animal()
    {

    }

    public void Eat()
    {
        System.Console.WriteLine("eating...");
    }
}