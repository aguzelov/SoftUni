﻿public class Dog : Animal
{
    public Dog()
        :base()
    {

    }

    public void Bark()
    {
        System.Console.WriteLine("barking...");
    }
}