﻿using System;

public static class Writer
{
    public static void WriteLine(string message)
    {
        Console.WriteLine(message);
    }
}