﻿public struct WeightIncreaseByAnimal
{
    public static double Hen = 0.35;
    public static double Owl = 0.25;
    public static double Mouse = 0.10;
    public static double Cat = 0.30;
    public static double Dog = 0.40;
    public static double Tiger = 1.00;
}