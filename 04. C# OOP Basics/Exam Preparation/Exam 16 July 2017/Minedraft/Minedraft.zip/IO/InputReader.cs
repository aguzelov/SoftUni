﻿using System;

public class InputReader
{
    public string ReadLine()
    {
        return Console.ReadLine();
    }
}