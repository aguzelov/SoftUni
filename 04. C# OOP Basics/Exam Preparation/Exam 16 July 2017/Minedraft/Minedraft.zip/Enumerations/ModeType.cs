﻿public enum ModeType
{
    Energy = 0,
    Half = 50,
    Full = 100
}