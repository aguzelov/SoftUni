﻿public class Startup
{
    public static void Main(string[] args)
    {
        var interpreter = new CommandInterpreter();

        interpreter.Start();
    }
}