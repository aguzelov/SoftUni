﻿public class Endurance : Stat
{
    public Endurance(int level) : base("Endurance", level)
    {
    }
}