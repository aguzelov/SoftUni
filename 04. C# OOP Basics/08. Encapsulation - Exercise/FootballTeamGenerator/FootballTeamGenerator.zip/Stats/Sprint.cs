﻿public class Sprint : Stat
{
    public Sprint(int level) : base("Sprint", level)
    {
    }
}