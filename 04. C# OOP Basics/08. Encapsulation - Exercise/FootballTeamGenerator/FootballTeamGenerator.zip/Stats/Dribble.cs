﻿public class Dribble : Stat
{
    public Dribble(int level) : base("Dribble", level)
    {
    }
}