﻿public class Passing : Stat
{
    public Passing(int level) : base("Passing", level)
    {
    }
}