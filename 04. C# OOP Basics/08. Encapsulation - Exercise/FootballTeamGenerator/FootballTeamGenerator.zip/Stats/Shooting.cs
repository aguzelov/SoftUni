﻿public class Shooting : Stat
{
    public Shooting(int level) : base("Shooting", level)
    {
    }
}