﻿using System;

public class BankAccount
{
    private int Id { get; set; }
    private decimal Balance { get; set; }

    public static void Main()
    {
        
        
    }
}
