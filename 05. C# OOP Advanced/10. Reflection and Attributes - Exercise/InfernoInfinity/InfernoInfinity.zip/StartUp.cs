﻿using P09_InfernoInfinity.Core;

namespace P09_InfernoInfinity
{
    internal class StartUp
    {
        private static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}