﻿namespace P09_InfernoInfinity.Contracts
{
    public interface IGem
    {
        int StrengthBonus { get; }

        int AgilityBonus { get; }

        int VitalityBonus { get; }
    }
}