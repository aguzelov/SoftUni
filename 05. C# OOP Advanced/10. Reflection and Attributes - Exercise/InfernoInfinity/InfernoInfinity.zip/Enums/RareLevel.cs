﻿namespace P09_InfernoInfinity.Enums
{
    public enum RareLevel
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}