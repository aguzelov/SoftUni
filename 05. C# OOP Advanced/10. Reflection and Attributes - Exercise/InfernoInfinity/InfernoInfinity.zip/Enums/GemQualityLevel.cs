﻿namespace P09_InfernoInfinity.Enums
{
    public enum GemQualityLevel
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}